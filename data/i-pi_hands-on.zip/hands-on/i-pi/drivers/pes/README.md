Potential energy surfaces for driver.x
======================================

This is meant to contain routines that provide a quick&dirty implementation of 
simple potential energy surfaces to use as tests with `driver.x`.
They are typically quickly put together and do not necessarily implement
all of the possible features (e.g. they might not have the virial, etc.),
or simply they are not implemented in clean, standard-compliant F90.

