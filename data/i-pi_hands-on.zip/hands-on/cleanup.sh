#!/bin/bash

rm ice-driver/[^i]* 
rm zundel-driver/*/[^ri]*
rm zundel-aims/*/[^cg]*
rm zundel-aims/[^ih]* 
