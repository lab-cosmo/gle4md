#!/bin/bash

awk 'BEGIN{nf=-1}; /#/{n=0; nf++}/[OH]/{n++; 
      if (n==1) {o1x=$2; o1y=$3; o1z=$4} 
      if (n==2) {o2x=$2; o2y=$3; o2z=$4}
      if (n==3) {hx=$2; hy=$3; hz=$4}
      if (n==4) { printf "%8d % 10.5f\n", nf, sqrt((hx-o1x)^2+(hy-o1y)^2+(hz-o1z)^2) - sqrt((hx-o2x)^2+(hy-o2y)^2+(hz-o2z)^2) } }' 
