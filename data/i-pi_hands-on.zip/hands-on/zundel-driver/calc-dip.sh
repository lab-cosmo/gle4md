#!/bin/bash
# COMPUTES THE TRPMD DIPOLE MOMENT DERIVATIVE AND PRINTS OUT TO STDOUT

prefix=$1

dt=1.0
paste $prefix* | awk -v dt=$dt 'BEGIN{nf=-1; tx=ty=tz=0;}; /#/{nf++;} !/#/{
      otx=tx; oty=ty; otz=tz;
      n=tx=ty=tz=0;

      for (i=1; i<=NF; i+=3) {tx+=$i; n++};
      for (i=2; i<=NF; i+=3) {ty+=$i; };
      for (i=3; i<=NF; i+=3) {tz+=$i; };

      if (nf>1) printf "%8.3f % 10.5f % 10.5f % 10.5f\n", nf*dt, (tx-otx)/(n*dt), (ty-oty)/(n*dt), (tz-otz)/(n*dt);
}'
